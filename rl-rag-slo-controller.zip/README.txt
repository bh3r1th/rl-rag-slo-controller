This folder contains a clean, neutral two-column LaTeX source suitable for arXiv submission.

Files:
- main.tex
- references.bib
- figures/*.png

To compile locally:
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
